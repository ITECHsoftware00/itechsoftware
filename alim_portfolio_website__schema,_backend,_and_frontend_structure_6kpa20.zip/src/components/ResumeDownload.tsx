export default function ResumeDownload() {
  return (
    <div className="flex justify-center my-8">
      <a
        href="/resume.pdf"
        download
        className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-6 rounded shadow"
      >
        Download Resume
      </a>
    </div>
  );
}

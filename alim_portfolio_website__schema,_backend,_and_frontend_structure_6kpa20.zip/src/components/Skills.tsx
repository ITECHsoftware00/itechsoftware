import { motion } from "framer-motion";

const skills = [
  {
    category: "Frontend",
    items: ["React", "React Native", "TailwindCSS", "TypeScript", "Next.js"],
  },
  {
    category: "Backend",
    items: ["Laravel", "Node.js", "Express", "PHP", "MySQL", "PostgreSQL"],
  },
  {
    category: "Blockchain",
    items: ["Solidity", "Web3.js", "Ethers.js"],
  },
  {
    category: "APIs & AI",
    items: ["REST", "GraphQL", "OpenAI", "LangChain"],
  },
];

export default function Skills() {
  return (
    <section className="py-12 max-w-3xl mx-auto">
      <motion.h2
        className="text-2xl font-semibold mb-6"
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
      >
        Skills
      </motion.h2>
      <div className="grid gap-6 md:grid-cols-2">
        {skills.map((skill) => (
          <motion.div
            key={skill.category}
            className="bg-slate-800 rounded-lg p-5 shadow"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h3 className="font-bold text-lg mb-2">{skill.category}</h3>
            <div className="flex flex-wrap gap-2">
              {skill.items.map((item) => (
                <span key={item} className="bg-indigo-600/20 text-indigo-300 px-2 py-1 rounded text-xs">{item}</span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

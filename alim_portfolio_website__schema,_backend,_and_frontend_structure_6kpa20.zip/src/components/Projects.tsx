import { motion } from "framer-motion";

const projects = [
  {
    title: "DeFi Platform",
    description: "A decentralized finance platform with smart contracts and real-time analytics.",
    tech: ["Solidity", "React", "Node.js"],
  },
  {
    title: "HSE App",
    description: "A health, safety, and environment mobile app for workplace compliance.",
    tech: ["React Native", "Laravel"],
  },
  {
    title: "WooCommerce Crypto Gateway",
    description: "A plugin enabling WooCommerce stores to accept crypto payments.",
    tech: ["PHP", "Solidity", "WordPress"],
  },
  {
    title: "Dream Analysis AI",
    description: "An AI-powered app for analyzing and interpreting dreams.",
    tech: ["Python", "React", "OpenAI"],
  },
];

export default function Projects() {
  return (
    <section className="py-12 max-w-3xl mx-auto">
      <motion.h2
        className="text-2xl font-semibold mb-6"
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
      >
        Projects
      </motion.h2>
      <div className="grid gap-6 md:grid-cols-2">
        {projects.map((proj, i) => (
          <motion.div
            key={proj.title}
            className="bg-slate-800 rounded-lg p-5 shadow"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
          >
            <h3 className="font-bold text-lg mb-2">{proj.title}</h3>
            <p className="mb-2 text-slate-300">{proj.description}</p>
            <div className="flex flex-wrap gap-2">
              {proj.tech.map((t) => (
                <span key={t} className="bg-indigo-600/20 text-indigo-300 px-2 py-1 rounded text-xs">{t}</span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

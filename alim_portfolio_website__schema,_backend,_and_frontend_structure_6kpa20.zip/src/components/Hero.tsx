import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="py-16 text-center">
      <motion.h1
        className="text-4xl md:text-5xl font-bold mb-6"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        Hi, I&apos;m Alim — a self-taught full-stack and blockchain developer specializing in
        <span className="text-indigo-500"> React, Laravel, Solidity, and mobile app development</span>.
      </motion.h1>
      <motion.p
        className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.7 }}
      >
        I’ve built everything from DeFi platforms to AI tools and health-tech apps. I&apos;m currently open to remote opportunities — let’s build the future together.
      </motion.p>
    </section>
  );
}

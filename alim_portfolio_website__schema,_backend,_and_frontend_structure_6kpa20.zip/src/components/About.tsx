import { motion } from "framer-motion";

export default function About() {
  return (
    <section className="py-12 max-w-2xl mx-auto">
      <motion.h2
        className="text-2xl font-semibold mb-4"
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
      >
        About Me
      </motion.h2>
      <motion.p
        className="text-slate-300"
        initial={{ opacity: 0, x: 30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
      >
        I&apos;m a self-taught developer with a passion for building impactful products. My journey spans DeFi platforms, health &amp; safety apps, WooCommerce crypto gateways, and AI-powered tools. I thrive in fast-paced, remote environments and love learning new technologies.
      </motion.p>
    </section>
  );
}

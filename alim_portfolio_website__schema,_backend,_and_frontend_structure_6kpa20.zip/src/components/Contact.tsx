import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { motion } from "framer-motion";

export default function Contact() {
  const submit = useMutation(api.contact.submit);
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    await submit(form);
    setLoading(false);
    setSent(true);
    setForm({ name: "", email: "", message: "" });
  }

  return (
    <section className="py-12 max-w-xl mx-auto">
      <motion.h2
        className="text-2xl font-semibold mb-6"
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
      >
        Contact
      </motion.h2>
      <form
        className="flex flex-col gap-4 bg-slate-800 p-6 rounded-lg shadow"
        onSubmit={handleSubmit}
      >
        <input
          className="p-2 rounded bg-slate-700 text-white"
          placeholder="Your Name"
          required
          value={form.name}
          onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
        />
        <input
          className="p-2 rounded bg-slate-700 text-white"
          placeholder="Your Email"
          type="email"
          required
          value={form.email}
          onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
        />
        <textarea
          className="p-2 rounded bg-slate-700 text-white"
          placeholder="Your Message"
          required
          rows={4}
          value={form.message}
          onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
        />
        <button
          type="submit"
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 rounded"
          disabled={loading}
        >
          {loading ? "Sending..." : "Send"}
        </button>
        {sent && (
          <p className="text-green-400 mt-2">Message sent! I&apos;ll get back to you soon.</p>
        )}
        <p className="text-slate-400 text-xs mt-2">Or email directly: <a href="mailto:itechsoftware60@gmail.com" className="underline">itechsoftware60@gmail.com</a></p>
      </form>
    </section>
  );
}

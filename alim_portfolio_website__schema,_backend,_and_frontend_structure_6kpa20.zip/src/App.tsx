import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import Hero from "./components/Hero";
import About from "./components/About";
import Projects from "./components/Projects";
import Skills from "./components/Skills";
import Contact from "./components/Contact";
import ResumeDownload from "./components/ResumeDownload";
import ThemeToggle from "./components/ThemeToggle";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 transition-colors">
      <header className="sticky top-0 z-10 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm p-4 flex justify-between items-center border-b border-slate-200 dark:border-slate-700">
        <h2 className="text-xl font-semibold accent-text">Alim&apos;s Portfolio</h2>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <SignOutButton />
        </div>
      </header>
      <main className="flex-1 flex flex-col gap-8 p-4 md:p-8">
        <Hero />
        <About />
        <Projects />
        <Skills />
        <ResumeDownload />
        <Contact />
      </main>
      <Toaster />
    </div>
  );
}

import { defineSchema } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

const applicationTables = {
  contactMessages: defineTable({
    name: v.string(),
    email: v.string(),
    message: v.string(),
    _read: v.optional(v.boolean()),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
